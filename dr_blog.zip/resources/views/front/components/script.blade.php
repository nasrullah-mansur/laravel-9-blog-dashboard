<script src="{{ asset('front/js/jquery.2.2.4.min.js') }}"></script>
<script src="{{ asset('front/js/bootstrap.bundle.min.js') }}"></script>

@stack('page_plugin_js')
<script src="{{ asset('front/js/custom.js') }}"></script>

@stack('custom_page_js')
